# 📚 Registro de Notas - Proyecto Vue.js

Aplicación simple hecha con Vue 3 (Options API) para registrar notas escolares.

## Cómo ejecutar el proyecto

1. Abrí una terminal en esta carpeta.
2. Instalá las dependencias:

   ```
   npm install
   ```

3. Iniciá el servidor de desarrollo:

   ```
   npm run dev
   ```

4. Abrí en el navegador la dirección que te muestre la terminal
   (generalmente `http://localhost:5173`).

## Estructura del proyecto

```
notas-app/
 ├── index.html
 ├── package.json
 ├── vite.config.js
 └── src/
      ├── main.js
      ├── App.vue          (formulario + lógica principal)
      └── components/
           └── Notas.vue   (muestra la lista de notas)
```

## Conceptos de Vue utilizados

- `data()` para guardar el estado.
- `v-model` para conectar los inputs.
- Métodos para validar y agregar notas.
- `props` para pasar datos de App.vue a Notas.vue.
- `v-for` para recorrer la lista de notas.
- `v-if` / `v-else` para mostrar mensajes y estados (Aprobado/Desaprobado).
