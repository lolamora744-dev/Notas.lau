import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Configuración básica de Vite para un proyecto Vue
export default defineConfig({
  plugins: [vue()]
})
